#ifndef _KD_PLUGIN_KEYBOARD_INTERNAL_H_
#define _KD_PLUGIN_KEYBOARD_INTERNAL_H_

typedef struct plugin_keyboard_plugin_data_s {
  int state;
} plugin_keyboard_plugin_data_t;

#endif
