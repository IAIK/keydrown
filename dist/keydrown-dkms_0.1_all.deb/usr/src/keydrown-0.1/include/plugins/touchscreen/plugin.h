#ifndef _KD_PLUGIN_TOUCHSCREEN_H_
#define _KD_PLUGIN_TOUCHSCREEN_H_

#include "keydrown.h"
#include "plugin.h"

extern event_plugin plugin_touchscreen;

#endif

