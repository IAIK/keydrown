#ifndef _KD_ARCH_8042_H_
#define _KD_ARCH_8042_H_

#include <linux/kernel.h>


#endif
