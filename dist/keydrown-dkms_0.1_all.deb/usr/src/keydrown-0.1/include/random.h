#ifndef _KD_RANDOM_H_
#define _KD_RANDOM_H_

#include <linux/kernel.h>

uint32_t get_random(uint32_t low, uint32_t high);

#endif

